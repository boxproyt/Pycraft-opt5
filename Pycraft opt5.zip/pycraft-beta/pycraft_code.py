from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import tkinter as tk
from tkinter import filedialog
import json

app = Ursina()

# Add background music
background_music = Audio('bg.WAV', loop=True, autoplay=True)

# Function to get world size from a Tkinter slider
def get_world_size():
    def on_slider_change(val):
        size_label.config(text=f'World Size: {int(val)}')
        update_world_preview(int(val))  # Update preview when slider changes

    # Initialize tkinter window for slider
    window = tk.Tk()
    window.title("World Size Selector")
    
    size_label = tk.Label(window, text="World Size: 20", font=("Arial", 12))
    size_label.pack(pady=10)

    # Create a canvas to display the world preview
    canvas = tk.Canvas(window, width=400, height=400)  # Increased size for better preview
    canvas.pack(pady=20)

    # Function to update the world preview on canvas
    def update_world_preview(size):
        canvas.delete("all")  # Clear the canvas
        block_size = 20  # Size of each block in the preview
        # Draw a grid based on the world size
        for i in range(size):
            for j in range(size):
                x1, y1 = i * block_size, j * block_size
                x2, y2 = x1 + block_size, y1 + block_size
                canvas.create_rectangle(x1, y1, x2, y2, outline="black", fill="lightgreen")

    # Create a slider to select world size
    world_size_slider = tk.Scale(window, from_=10, to_=100, orient="horizontal", length=300, command=on_slider_change)
    world_size_slider.set(20)  # Default value
    world_size_slider.pack(pady=20)

    # Create an OK button to accept the size and close the window
    def on_ok_button_click():
        global world_size
        world_size = world_size_slider.get()
        window.destroy()

    ok_button = tk.Button(window, text="OK", command=on_ok_button_click)
    ok_button.pack(pady=10)

    window.mainloop()

# Call the function to get world size at the start
world_size = 20  # Default size
get_world_size()

# Add a Sky with a custom texture
Sky()

# Define the new sky texture that you want after seconds
new_sky_texture = 'night-sky.jpg'  # Replace with your new sky texture

# Function to change the sky after  seconds
def change_sky_after_time():
    start_time = time.time()  # Record the start time
    while True:
        elapsed_time = time.time() - start_time  # Calculate elapsed time
        if elapsed_time >= 15:
            Sky.texture = new_sky_texture  # Change sky texture
            break  # Exit the loop after the sky changes
        time.sleep(0.1)  # Sleep briefly to prevent excessive CPU usage

# Call the function in a background thread to avoid blocking the main thread
from threading import Thread
sky_change_thread = Thread(target=change_sky_after_time)
sky_change_thread.start()

# Create a directional light with soft shadows
light = DirectionalLight()
light.look_at(Vec3(1, -1, 1.5))  # Adjust the light direction
light.shadow_map_resolution = (2048, 2048)  # Use a high-resolution shadow map for smooth edges
light.color = color.white * 0.8  # Soften the light intensity
light.shadow_caster = True  # Enable shadows
light.shadow_softness = 1  # Simulate blurry shadows (higher values = blurrier)

# Add an ambient light for smooth lighting
ambient_light = AmbientLight()
ambient_light.color = color.white * 0.5  # Dim ambient light to create a balance

# Create a player and set its initial position above ground
player = FirstPersonController()
player.position = (10, 10, 10)  # Ensure the player starts slightly above the ground

# Define different block types with corresponding sprite image names and sound files
block_types = [
    {'name': 'Grass', 'texture': 'grass.png', 'sprite': 'grass-sprite.png', 'place_sound': 'block-place-grass.mp3', 'break_sound': 'block-break-grass.mp3', 'walk_sound': 'walk-grass.mp3'},
    {'name': 'Stone', 'texture': 'stone.png', 'sprite': 'stone-sprite.png', 'place_sound': 'block-place-stone.mp3', 'break_sound': 'block-break-stone.mp3', 'walk_sound': 'walk-stone.mp3'},
    {'name': 'Wood', 'texture': 'wood.png', 'sprite': 'wood-sprite.png', 'place_sound': 'block-place-wood.mp3', 'break_sound': 'block-break-wood.mp3', 'walk_sound': 'walk-wood.mp3'},
    {'name': 'Brick', 'texture': 'brick.png', 'sprite': 'brick-sprite.png', 'place_sound': 'block-place-stone.mp3', 'break_sound': 'block-break-stone.mp3', 'walk_sound': 'walk-stone.mp3'},
    {'name': 'Sand', 'texture': 'sand.png', 'sprite': 'sand-sprite.png', 'place_sound': 'block-place-grass.mp3', 'break_sound': 'block-break-grass.mp3', 'walk_sound': 'walk-grass.mp3'},
    {'name': 'Fire', 'texture': 'fire.png', 'sprite': 'lighter-sprite.png', 'place_sound': 'block-place-fire.mp3', 'break_sound': 'block-break-fire.mp3', 'walk_sound': 'walk-fire.mp3'},
    {'name': 'Glass', 'texture': 'glass.png', 'sprite': 'glass-sprite.png', 'place_sound': 'glass_place.mp3', 'break_sound': 'glass_break.mp3', 'walk_sound': 'walk-wood.mp3'},
    {'name': 'Light', 'texture': 'light.png', 'sprite': 'light-sprite.png', 'place_sound': 'block-place-wood.mp3', 'break_sound': 'block-break-wood.mp3', 'walk_sound': 'walk-wood.mp3'},
    {'name': 'Planks', 'texture': 'planks_new.png', 'sprite': 'planks-sprite.png', 'place_sound': 'block-place-wood.mp3', 'break_sound': 'block-break-wood.mp3', 'walk_sound': 'walk-wood.mp3'},
]

# Initialize with the first block type
current_block_type = 0

boxes = []

# Load sound effects for each block type
block_sounds = {}

for block in block_types:
    block_sounds[block['name']] = {
        'place': Audio(block['place_sound'], loop=False, autoplay=False),
        'break': Audio(block['break_sound'], loop=False, autoplay=False),
        'walk': Audio(block['walk_sound'], loop=True, autoplay=False)
    }

# Create the world grid dynamically based on the world size
def create_world():
    global boxes
    for i in range(world_size):
        for j in range(world_size):
            box = Entity(model='cube', position=(j, 0, i), texture='grass.png',
                         parent=scene, origin_y=0.5, collider='box', shadow=True)
            boxes.append(box)

create_world()  # Create initial world grid

# Track collision visibility
collisions_visible = False

# Create a 2D Sprite for block preview (replaces the text)
block_preview_sprite = Sprite(parent=camera.ui, texture=block_types[current_block_type]['sprite'],
                               position=(0.55, -0.35), scale=(1, 1))  # Increase scale for better visibility
block_preview_sprite.texture.filtering = False  # Disable texture filtering to prevent blurriness

def save_world(file_path):
    world_data = {
        'player_position': list(player.position),
        'blocks': []
    }
    for box in boxes:
        block_data = {
            'block': block_types[current_block_type]['name'],
            'position': list(box.position),
            'texture': box.texture.name  # Save texture as a string (filename)
        }
        world_data['blocks'].append(block_data)
    
    with open(file_path, 'w') as f:
        json.dump(world_data, f, indent=4)
    print(f"World saved to {file_path}")


def load_world(file_path):
    global boxes
    for box in boxes:
        destroy(box)
    boxes = []

    with open(file_path, 'r') as f:
        world_data = json.load(f)
        # Load player position
        player.position = Vec3(*world_data['player_position'])
        
        # Load blocks
        for block_data in world_data['blocks']:
            block_name = block_data['block']
            position = Vec3(*block_data['position'])
            texture_filename = block_data['texture']
            # Load the texture from filename
            texture = load_texture(texture_filename)
            box = Entity(model='cube', position=position, texture=texture,
                         parent=scene, origin_y=0.5, collider='box', shadow=True)
            boxes.append(box)
    print(f"World loaded from {file_path}")


# Input handling (Escape, left/right click, etc.)
def input(key):
    global current_block_type, collisions_visible

    # Close the game when Escape is pressed
    if key == 'escape':
        application.quit()

    # Toggle collision visibility with F3
    if key == 'f3':
        collisions_visible = not collisions_visible
        for box in boxes:
            box.collider.visible = collisions_visible  # Update all existing blocks

    # Switch block type with number keys
    if key == '1':
        current_block_type = 0
    elif key == '2':
        current_block_type = 1
    elif key == '3':
        current_block_type = 2
    elif key == '4':
        current_block_type = 3
    elif key == '5':
        current_block_type = 4
    elif key == '6':
        current_block_type = 5
    elif key == '7':
        current_block_type = 6
    elif key == '8':
        current_block_type = 7
    elif key == '9':
        current_block_type = 8

    # Update the block preview sprite texture to the selected block's sprite
    block_preview_sprite.texture = block_types[current_block_type]['sprite']

    # Add or remove blocks with mouse interaction
    if key == 'left mouse down' or key == 'right mouse down':
        for box in boxes:
            if box.hovered:
                if key == 'left mouse down':
                    # Place a block
                    block_sounds[block_types[current_block_type]['name']]['place'].play()
                    new_block = Entity(model='cube', position=box.position + mouse.normal,
                                       texture=block_types[current_block_type]['texture'],
                                       parent=scene, origin_y=0.5, collider='box', shadow=True)
                    # Ensure the new block gets the correct collision visibility
                    new_block.collider.visible = collisions_visible
                    boxes.append(new_block)
                elif key == 'right mouse down':
                    # Break a block
                    for block_type in block_types:
                        if box.texture.name == block_type['texture']:
                            block_sounds[block_type['name']]['break'].play()
                            break
                    boxes.remove(box)
                    destroy(box)

    # Save world with Ctrl + S
    if key == '[':
        file_path = file_dialog('save')  # Open save file dialog
        if file_path:
            save_world(file_path)

    # Open world with Ctrl + O
    if key == ']':
        file_path = file_dialog('open')  # Open file dialog
        if file_path:
            load_world(file_path)

# Utility function to open file dialog (using tkinter)
def file_dialog(action='open'):
    root = tk.Tk()
    root.withdraw()  # Hide the root window
    file_path = None

    if action == 'save':
        file_path = filedialog.asksaveasfilename(defaultextension='.fishy', filetypes=[('Fishy World Files', '*.fishy')])
    elif action == 'open':
        file_path = filedialog.askopenfilename(filetypes=[('Fishy World Files', '*.fishy')])

    return file_path

app.run()